package simulate;
import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Iterator;
import java.util.Set;

public class Simul{
	 public static int clock = 13;
	 public static int fetch;
	 public static int issue;
	 public static int read;
	 public static int exec;
	 public static int write;
	 public static int first_inst = 0;
	 public static int inst_unit = 0;
	 public static int prev_issue = 0;
	 public static int prev_write = 0;
	 public static int LI_write = 0;
	 public static char RAW = 'N';
	 public static char WAW = 'N';
	 public static char Struct = 'N';
	 public static int lp = 0;
	 public static int loop_index;
	 public static int i = 0;
	 public static int cache_empty = 0;
	 public static int prev_fetch = 0;
		 static HashMap<String, Integer> hmap = new HashMap<String, Integer>();
		 static String[] registers = {"R1","R2","R3","R4","R5","R6","R7","R8","R9","R10","R11","R12","R13","R14","R15","R16","R17","R18","R19","R20","R21","R22","R23","R24","R25","R26","R27","R28","R29","R30","R31","R32"};
		 
		 static Map<String, int[]> rmap = new HashMap<String, int[]>();
		 static Map<String, int[]> Hmap = new HashMap<String, int[]>();
		 
		 static HashMap<String, Integer> fmap = new HashMap<String, Integer>();
		 static String[] regist = {"F1","F2","F3","F4","F5","F6","F7","F8","F9","F10","F11","F12","F13","F14","F15","F16","F17","F18","F19","F20","F21","F22","F23","F24","F25","F26","F27","F28","F29","F30","F31","F32"};

	public static void sim(String[] instArray) throws Exception
	{
		 System.out.print("\n");
		 String line;
		 
		 int size = registers.length;
		 
		 int[] Iarr = new int[2];
		 Iarr[0] = 0;
		 Iarr[1] = 0;
		 
		 for(int j = 0; j<2; j++)
		 {
			rmap.put(registers[j],Iarr); 
		 }
		 
		 for(int j = 0; j<2; j++)
		 {
			Hmap.put(regist[j],Iarr); 
		 }
		 
		/* int int1 = smap.get("R1")[0];
		 System.out.println(int1);
		 int int2 = smap.get("R2")[1];
		 System.out.println(int2);*/
		 
		 /*for(Entry<String, int[]> entry : smap.entrySet())
		    {   //print keys and values
		         System.out.print(entry.getKey() + " : " +entry.getValue() + " ");
		    }*/
		 
		 for(int j = 0; j<size; j++)
		 {
			hmap.put(registers[j],0); 
		 }
		 
		 int size1 = registers.length;
		 
		 for(int j = 0; j<size1; j++)
		 {
			fmap.put(regist[j],0); 
		 }
		 
		 for (i = 0; i < instArray.length; i++) 
		 
		 { 
			 if (i > 0) {
	            System.out.print("\n ");
	         }
	        line = instArray[i];
	        System.out.print(line);
	        System.out.println("\nvalue at start i:" + "" + i);
	        parseInstLine(line);
	         }
	}



private static void parseInstLine(String line) throws Exception {
	String tokens[] = new String[5];
	line = line.trim();
	line = line.toUpperCase();
	String sourceRegister1, sourceRegister2, destinationRegister;
	String[] operands;
	int offset;
	int immediate;
	/*for(Entry<String, Integer> entry : hmap.entrySet())
    {   //print keys and values
         System.out.print(entry.getKey() + " : " +entry.getValue());
    }*/

	/* CHECK IF IT HAS A LOOP */
	String loopName = "";
	if (line.contains(":")) {
		int index = line.lastIndexOf(':');
		loopName = line.substring(0, index);
		line = line.substring(index + 1);
		line = line.trim();
		lp++;
		loop_index = i;
		loop_index--;
		
	}

	tokens = line.split("[\\s]", 2);
	String opcode = tokens[0].trim().toUpperCase();

	// System.out.println(Arrays.toString(tokens));

	switch (opcode) {
	case "LW":
		operands = getOperands(tokens);
		destinationRegister = operands[0];
		offset = Integer.parseInt(operands[1].substring(0,
				operands[1].lastIndexOf('(')));
		sourceRegister1 = operands[1].substring(
				operands[1].lastIndexOf('(') + 1,
				operands[1].lastIndexOf(')'));
		break;
	case "L.D":
		operands = getOperands(tokens);
		destinationRegister = operands[0];
		
		offset = Integer.parseInt(operands[1].substring(0,
				operands[1].lastIndexOf('(')));
		
		sourceRegister1 = operands[1].substring(
				operands[1].lastIndexOf('(') + 1,
				operands[1].lastIndexOf(')'));
		//int val = hmap.get(sourceRegister1);
		int val = rmap.get(sourceRegister1)[1];
		int val1 = offset + val;
		//fmap.put(destinationRegister, val1);
		fetch = prev_issue;
		issue = fetch + 1;
		read = issue + 1;
		exec = read + 1;
		int[] parr = new int[2];
		 parr[0] = write;
		 parr[1] = val1;
		Hmap.put(destinationRegister,parr);
		for(Entry<String, Integer> entry : fmap.entrySet())
	    {   //print keys and values
	         System.out.print(entry.getKey() + " : " +entry.getValue() + " ");
	    }
		break;
	case "SW":
		operands = getOperands(tokens);
		sourceRegister1 = operands[0];
		offset = Integer.parseInt(operands[1].substring(0,
				operands[1].lastIndexOf('(')));
		sourceRegister2 = operands[1].substring(
				operands[1].lastIndexOf('(') + 1,
				operands[1].lastIndexOf(')'));
		break;
	case "S.D":
		operands = getOperands(tokens);
		sourceRegister1 = operands[0];
		offset = Integer.parseInt(operands[1].substring(0,
				operands[1].lastIndexOf('(')));
		sourceRegister2 = operands[1].substring(
				operands[1].lastIndexOf('(') + 1,
				operands[1].lastIndexOf(')'));
		break;
	case "ADD.D":
		operands = getOperands(tokens);
		destinationRegister = operands[0];
		sourceRegister1 = operands[1];
		sourceRegister2 = operands[2];
		int val2 = fmap.get(sourceRegister1);
		int val3 = fmap.get(sourceRegister2);
		int val4 = val2 + val3;
		fmap.put(destinationRegister, val4);
		for(Entry<String, Integer> entry : fmap.entrySet())
	    {   //print keys and values
	         System.out.print(entry.getKey() + " : " +entry.getValue() + " ");
	    }
		break;
	case "SUB.D":
		operands = getOperands(tokens);
		destinationRegister = operands[0];
		sourceRegister1 = operands[1];
		sourceRegister2 = operands[2];
		int val5 = fmap.get(sourceRegister1);
		int val6 = fmap.get(sourceRegister2);
		int val7 = val5 - val6;
		fmap.put(destinationRegister, val7);
		for(Entry<String, Integer> entry : fmap.entrySet())
	    {   //print keys and values
	         System.out.print(entry.getKey() + " : " +entry.getValue() + " ");
	    }
		break;
	case "MUL.D":
		operands = getOperands(tokens);
		destinationRegister = operands[0];
		sourceRegister1 = operands[1];
		sourceRegister2 = operands[2];
		int val8 = fmap.get(sourceRegister1);
		int val9 = fmap.get(sourceRegister2);
		int val10 = val8 * val9;
		fmap.put(destinationRegister, val10);
		for(Entry<String, Integer> entry : fmap.entrySet())
	    {   //print keys and values
	         System.out.print(entry.getKey() + " : " +entry.getValue() + " ");
	    }
		break;
	case "DIV.D":
		operands = getOperands(tokens);
		destinationRegister = operands[0];
		sourceRegister1 = operands[1];
		sourceRegister2 = operands[2];
		break;
	case "DADD":
		operands = getOperands(tokens);
		destinationRegister = operands[0];
		sourceRegister1 = operands[1];
		sourceRegister2 = operands[2];
		break;
	case "DADDI":
		operands = getOperands(tokens);
		destinationRegister = operands[0];
		sourceRegister1 = operands[1];
		immediate = Integer.parseInt(operands[2]);
		int val11 = hmap.get(sourceRegister1);
		int val12 = val11 + immediate;
		hmap.put(destinationRegister, val12);
		for(Entry<String, Integer> entry : fmap.entrySet())
	    {   //print keys and values
	         System.out.print(entry.getKey() + " : " +entry.getValue() + " ");
	    }
		break;
	case "DSUB":
		operands = getOperands(tokens);
		destinationRegister = operands[0];
		sourceRegister1 = operands[1];
		sourceRegister2 = operands[2];
		int val13 = hmap.get(sourceRegister1);
		int val14 = hmap.get(sourceRegister2);
		int val15 = val13 - val14;
		hmap.put(destinationRegister, val15);
		for(Entry<String, Integer> entry : hmap.entrySet())
	    {   //print keys and values
	         System.out.print(entry.getKey() + " : " +entry.getValue() + " ");
	    }
		break;
	case "DSUBI":
		operands = getOperands(tokens);
		destinationRegister = operands[0];
		sourceRegister1 = operands[1];
		immediate = Integer.parseInt(operands[2]);
		break;
	case "AND":
		operands = getOperands(tokens);
		destinationRegister = operands[0];
		sourceRegister1 = operands[1];
		sourceRegister2 = operands[2];
		break;
	case "ANDI":
		operands = getOperands(tokens);
		destinationRegister = operands[0];
		sourceRegister1 = operands[1];
		immediate = Integer.parseInt(operands[2]);
		break;
	case "OR":
		operands = getOperands(tokens);
		destinationRegister = operands[0];
		sourceRegister1 = operands[1];
		sourceRegister2 = operands[2];
		break;
	case "ORI":
		operands = getOperands(tokens);
		destinationRegister = operands[0];
		sourceRegister1 = operands[1];
		immediate = Integer.parseInt(operands[2]);
		break;
	case "BEQ":
		operands = getOperands(tokens);
		sourceRegister1 = operands[0];
		sourceRegister2 = operands[1];
		destinationRegister = operands[2];
		break;
	case "BNE":
		operands = getOperands(tokens);
		sourceRegister1 = operands[0];
		sourceRegister2 = operands[1];
		destinationRegister = operands[2];
		int val16 = hmap.get(sourceRegister1);
		int val17 = hmap.get(sourceRegister2);
		if(val16 != val17)
		{
			i = loop_index;
			System.out.println("\nvalue of i:" + "" + i);
		}
		break;
	case "HLT":
		break;
	case "J":
		operands = getOperands(tokens);
		destinationRegister = operands[0];
		break;
	case "LI":
		operands = getOperands(tokens);
		//String cnt = operands[0];
		destinationRegister = operands[0];
		//String cnt1 = cnt.substring(1, cnt.length());
		//int count = Integer.parseInt(cnt1);
		int value = Integer.parseInt(operands[1]);
		if(first_inst == 0)
		{
			//System.out.println("Int_unit is zero");
			fetch = clock;
			issue = fetch + 1;
			read = issue + 1;
			exec = read + 1;
			write = exec + 1;
			inst_unit = write;
			prev_issue = issue;
			prev_write = write;
			LI_write = write;
			prev_fetch = fetch;
			hmap.put(destinationRegister,value);
			int[] parr1 = new int[2];
			 parr1[0] = write;
			 parr1[1] = value;
			rmap.put(destinationRegister,parr1);
			int int1 = rmap.get(destinationRegister)[0];
			 System.out.println(int1);
			 int int2 = rmap.get(destinationRegister)[1];
			 System.out.println(int2);
			/*for(Entry<String, Integer> entry : hmap.entrySet())
		    {   //print keys and values
		         System.out.print(entry.getKey() + " : " +entry.getValue() + " ");
		    }*/
			System.out.println("\t" + fetch + " " + issue + " " + read + " " + exec + " " + write);
			first_inst = 1;
			RAW = 'N';
			WAW = 'N';
			Struct = 'N';
		}
		else
		{
			if(i%4 == 0)
			{
				cache_empty = 1;
			}
			if(cache_empty == 1)
			{
				fetch = prev_fetch + 13;
			}
			else
			{
				fetch = prev_issue;
			}
			//check for structural hazard
			if((fetch+1)<=LI_write)
			{
				Struct = 'Y';
				issue = LI_write+1;
				read =  issue + 1;
				exec = read + 1;
				write = exec + 1;
				prev_issue = issue;
				LI_write = write;
				prev_fetch = fetch;
			}
			else
			{
				issue = fetch + 1;
				read =  issue + 1;
				exec = read + 1;
				write = exec + 1;
				prev_issue = issue;
				LI_write = write;
				prev_fetch = fetch;
			}
			hmap.put(destinationRegister,value);
			int[] parr2 = new int[2];
			 parr2[0] = write;
			 parr2[1] = value;
			rmap.put(destinationRegister,parr2);
			int int1 = rmap.get(destinationRegister)[0];
			 System.out.println(int1);
			 int int2 = rmap.get(destinationRegister)[1];
			 System.out.println(int2);
			 System.out.println("\t" + fetch + " " + issue + " " + read + " " + exec + " " + write);
			 RAW = 'N';
			WAW = 'N';
			Struct = 'N';
			/*for(Entry<String, Integer> entry : hmap.entrySet())
		    {   //print keys and values
		         System.out.print(entry.getKey() + " : " +entry.getValue() + " ");
		    }*/
			//System.out.println("\t" + fetch + " " + issue + " " + read + " " + exec + " " + write);
		}
		break;
	default:
		throw new Exception("Illegal Instruction encountered");

	}
	loopName = (loopName != null && loopName.length() > 0) ? loopName
			+ ": " : "";
}

private static String[] getOperands(String[] tokens) throws Exception {

	String argListArray[] = new String[3];
	String arg1[] = new String[3];
	if (!tokens[0].trim().equalsIgnoreCase("HLT")) {
		String argList = tokens[1];
		argListArray = argList.trim().split(",");
		for (int i = 0; i < argListArray.length; i++) {
			String arg = argListArray[i] = argListArray[i].trim();
			/* VALIDATE ARG */
			if (arg.charAt(0) != 'R' && arg.charAt(0) != 'F') {
				if (arg.charAt(0) < '0' || arg.charAt(0) > '9')
						if (!tokens[0].equalsIgnoreCase("BEQ")
								&& !tokens[0].equalsIgnoreCase("BNE")
								&& !tokens[0].equalsIgnoreCase("J"))
							throw new Exception("Incorrect Format in inst.txt at Line");
			}
			arg1[i] = argListArray[i];
		}
	}
	return arg1;
}
}

